# RCM Fase 4 — Prototipo PWA v0.1

Este es un prototipo independiente, NO una migración validada del motor RCM v25.

## Funciones implementadas
- Captura de equipo y contexto operacional.
- Registro de funciones/fallas funcionales y modos/efectos.
- Registro guiado de evaluaciones RCM **sin selección automática**.
- Registro de tareas con intervalos ingresados y justificados manualmente.
- Identificadores locales y bloqueo de eliminación cuando hay registros dependientes.
- Guardado local en navegador, exportación/importación JSON, impresión o PDF del plan.
- Instalación PWA al publicarse en HTTPS o localhost.

## Ejecutar
Publicar esta carpeta en un servidor HTTPS estático (p. ej. GitHub Pages) o ejecutar `python -m http.server 8000` desde la carpeta y abrir http://localhost:8000. Para probar en un celular, publicar en HTTPS. Abrir `index.html` directamente sirve para una vista básica, pero puede desactivar la instalación PWA.

## Limitaciones críticas
- No incluye árbol de decisión SAE JA1011 ni lógica VBA v25. No existe conformidad metodológica demostrada.
- No calcula frecuencias ni aprueba tareas. Toda tarea está pendiente.
- No hay sincronización, autenticación, historial de cambios ni control de revisión.
- No hay importación/exportación XLSX, ni 61 casos de prueba ejecutados.
- Los datos se guardan en localStorage y pueden perderse al limpiar el navegador; exportar JSON.
- No usar para decisiones operativas de seguridad ni como evidencia de verificación funcional.

## Próxima etapa
Comparar exhaustivamente las reglas de la v25 y los ejemplos docentes, definir casos de aceptación, implementar el árbol RCM con tests, y añadir trazabilidad, edición segura, respaldo y exportación estructurada.
